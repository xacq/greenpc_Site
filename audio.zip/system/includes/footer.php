<footer class="text-center text-lg-start mt-auto">
    <div class="container p-4 text-center color-primario">
        <p>&copy; 2025 <a class="link-primario" href="https://greenpc.dev/"> Green PC</a>. Todos los derechos reservados. </p>
    </div>
</footer>

<!-- Bootstrap JS y dependencias -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
