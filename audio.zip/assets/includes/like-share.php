<section class="mb-5">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <h3 class="h5 mb-3">¿Te resultó útil este artículo?</h3>
                                <div class="d-flex justify-content-center gap-3">
                                    <button class="btn btn-primario rounded-pill">
                                        <i class="bi bi-hand-thumbs-up me-2"></i>Me gusta
                                    </button>
                                    <button class="btn btn-secundario rounded-pill">
                                        <i class="bi bi-share me-2"></i>Compartir
                                    </button>
                                </div>
                            </div>
                        </div>
                    </section>