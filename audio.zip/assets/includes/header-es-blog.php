
</head>

<body class="index-page">


<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="../index.php" class="logo d-flex align-items-center me-auto me-lg-0">
        <img src="../assets/img/logo.png" alt="">
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="../index.php" class="active">Inicio<br></a></li>
          <li><a href="../blog.php" class="active">Blogs<br></a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
      <a class="btn-getstarted" href="../system/index.php"> <i class="bi bi-app-indicator"></i> Login</a>
    </div>
  </header>

  <!-- Contenido Principal -->
  <main class="main"> <!-- margen para evitar superposición con header fijo -->

      <!-- Barra de progreso -->
      <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>
